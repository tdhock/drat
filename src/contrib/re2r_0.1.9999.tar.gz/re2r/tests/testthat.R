library(testthat)
library(re2r)
library(stringi)

large_vec_len = 2200000

test_check("re2r")
